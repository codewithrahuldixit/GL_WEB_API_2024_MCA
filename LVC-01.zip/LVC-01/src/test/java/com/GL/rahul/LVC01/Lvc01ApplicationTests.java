package com.GL.rahul.LVC01;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Lvc01ApplicationTests {

	@Test
	void contextLoads() {
	}

}
