package com.GL.rahul.LVC01;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Lvc01Application {

	public static void main(String[] args) {
		SpringApplication.run(Lvc01Application.class, args);
	}

}
