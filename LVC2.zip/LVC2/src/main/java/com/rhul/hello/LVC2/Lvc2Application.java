package com.rhul.hello.LVC2;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Lvc2Application {

	public static void main(String[] args) {
		SpringApplication.run(Lvc2Application.class, args);
	}

}
